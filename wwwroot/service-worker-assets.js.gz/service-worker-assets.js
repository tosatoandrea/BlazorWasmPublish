﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-8aM9R9K90X6h+KPDW4OzrEh071mAs7dvAQxjBxAZQAc=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-rldnE7wZYJj3Q43t5v8fg1ojKRwyt0Wtfm+224CacZs=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-vqZRLl7bdOqsF2YS22hlltjuCIIFofpNHtcd\/BZ\/fJY=",
      "url": "index.html"
    },
    {
      "hash": "sha256-YFbFB5PEGp78w06hN96\/rJTYZIdfANC1XwJWw1n69mA=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yzFf+O\/mlH+Q9klUSqXP2kxGKOUFLPxaww8da8fKhGU=",
      "url": "sample-data\/weather.json"
    },
    {
      "hash": "sha256-pro72EdtT0dffSKHvmvZ6KMWjRqZK9iKsN+T6OaX\/WM=",
      "url": "_framework\/Microsoft.CSharp.dll"
    },
    {
      "hash": "sha256-yqKfbt+FMK3YQWz8QzHuAFqxIxN5MxOW+R11ltXmIKE=",
      "url": "_framework\/Microsoft.VisualBasic.Core.dll"
    },
    {
      "hash": "sha256-mIhR7vYCzg5aKYGk0F7p4UfbocIRqW2JzqN3I3ssbyU=",
      "url": "_framework\/Microsoft.VisualBasic.dll"
    },
    {
      "hash": "sha256-DvWtO9vkZk2m2gV8nmssO2XgnjPY85\/nh9f905qtbzg=",
      "url": "_framework\/Microsoft.Win32.Primitives.dll"
    },
    {
      "hash": "sha256-ieKAVn86se9OWurDqWe1YVEO6o1K0WL626aB2wI24Qw=",
      "url": "_framework\/Microsoft.Win32.Registry.dll"
    },
    {
      "hash": "sha256-jjViaRLCIMLo442RyQm2\/8StQvD7KqgKnHvvZ3sfCc8=",
      "url": "_framework\/System.AppContext.dll"
    },
    {
      "hash": "sha256-eww\/hqlRYrQxHrQNeVesJ07ohHhyPKsBAZKtrHwVRWU=",
      "url": "_framework\/System.Buffers.dll"
    },
    {
      "hash": "sha256-2c6eQYFY1AdPnPtrs5SM\/zFqyAPgP2ayWL0hzeNRKaM=",
      "url": "_framework\/System.Collections.Concurrent.dll"
    },
    {
      "hash": "sha256-exIDCCaR7+lKQC\/9AC1H24jyArbzdv3YWeGgFi9hvSw=",
      "url": "_framework\/System.Collections.Immutable.dll"
    },
    {
      "hash": "sha256-uD1rc7XKt91GRlB1YLOp\/YFU7ACk7zuizqkK1MFUZ\/8=",
      "url": "_framework\/System.Collections.NonGeneric.dll"
    },
    {
      "hash": "sha256-qCPa\/nmT1V1jSVUcdP3WFpIVzA\/sjPLiespU14hM3eY=",
      "url": "_framework\/System.Collections.Specialized.dll"
    },
    {
      "hash": "sha256-hVTZK9tURI+fNbhdbdAi7v4pqlTUJ2sLgj7jKl78vho=",
      "url": "_framework\/System.Collections.dll"
    },
    {
      "hash": "sha256-ofJ4X6jSDpeEjqprcd67AmdLykJzMBMIujEhLTn4Rio=",
      "url": "_framework\/System.ComponentModel.Annotations.dll"
    },
    {
      "hash": "sha256-i2zo0D+Tt24f4TzcYWn85nvM6xxCMxzzLQOpMMjEKFc=",
      "url": "_framework\/System.ComponentModel.DataAnnotations.dll"
    },
    {
      "hash": "sha256-f2lJ9GCR\/adTpKcg5YcR7FxZ0q1x4AbVIwtkhvFUSnQ=",
      "url": "_framework\/System.ComponentModel.EventBasedAsync.dll"
    },
    {
      "hash": "sha256-VhPt6X9WFgV7ZCpfFZYCDTzACUKNk6PTxEZedhrkJkI=",
      "url": "_framework\/System.ComponentModel.Primitives.dll"
    },
    {
      "hash": "sha256-vUVHa4WqcNmzj63sMg0tCjxnymLDB\/\/3jW8eX\/OL24k=",
      "url": "_framework\/System.ComponentModel.TypeConverter.dll"
    },
    {
      "hash": "sha256-+5M37McG8eaLSJq4TvtwtToeZngunj04yzpRdXZYdfY=",
      "url": "_framework\/System.ComponentModel.dll"
    },
    {
      "hash": "sha256-rCy6XkN3OVK\/\/ah39MGR8ihFQDxbFNbih4Wg0fdtOAc=",
      "url": "_framework\/System.Configuration.dll"
    },
    {
      "hash": "sha256-xt10DRhcsvXn0P2AN8H2V53yUV8glRmPeQbJr9K64mY=",
      "url": "_framework\/System.Console.dll"
    },
    {
      "hash": "sha256-ZIlnjlEQAAZ2Wp1iuDln6GhNJkGMwnky9025m38luQ8=",
      "url": "_framework\/System.Core.dll"
    },
    {
      "hash": "sha256-y970rX4ybf3fj4S5k0H0sht7pNx+78tRzoPXOD2ny0s=",
      "url": "_framework\/System.Data.Common.dll"
    },
    {
      "hash": "sha256-yXSpB2zitKynn6lWDNIwLnF\/dDT8lqa\/3\/OL2fMDKsU=",
      "url": "_framework\/System.Data.DataSetExtensions.dll"
    },
    {
      "hash": "sha256-tOLZn2Kh8Tx90NFc+OkiGcTnxWUJjvGDyB1\/MujsMws=",
      "url": "_framework\/System.Data.dll"
    },
    {
      "hash": "sha256-OJT4DJTWCGTuQUovZ7AkVtOAZBQS2SKBFlrUncroN2M=",
      "url": "_framework\/System.Diagnostics.Contracts.dll"
    },
    {
      "hash": "sha256-3pnUmbP5X+MiX3S\/yaIrB\/4D42fp5K+5\/6dK+9FgDHg=",
      "url": "_framework\/System.Diagnostics.Debug.dll"
    },
    {
      "hash": "sha256-ufELrHle3ZmLmVkpBceHUgmLX4PXs8eOZ+koaHl+WZs=",
      "url": "_framework\/System.Diagnostics.DiagnosticSource.dll"
    },
    {
      "hash": "sha256-+5HSIbWoXaWm6d7aOtIaH6IRkOD3G5Wwl3ZSFfQYnwg=",
      "url": "_framework\/System.Diagnostics.FileVersionInfo.dll"
    },
    {
      "hash": "sha256-yV2macdOV3Q603dV6zJ7gLzfAje7jVFqApHpI\/xaeVw=",
      "url": "_framework\/System.Diagnostics.Process.dll"
    },
    {
      "hash": "sha256-u++kq1867fIVwucxG4mAhc1sxsmV+rdwBXqsYxOLWsc=",
      "url": "_framework\/System.Diagnostics.StackTrace.dll"
    },
    {
      "hash": "sha256-Ke7UZx8p8U3bHtkOpfDQ2sfB9VGX+gd437guvo9TijQ=",
      "url": "_framework\/System.Diagnostics.TextWriterTraceListener.dll"
    },
    {
      "hash": "sha256-EKBWksHA0nwz6DA1WNMd9q8NvtTr6tLKXY5f\/DEQMQU=",
      "url": "_framework\/System.Diagnostics.Tools.dll"
    },
    {
      "hash": "sha256-jh36HSXJrTeUeOwWl8CaT1ZrJQO2NM4kn7MPc0o0DJ4=",
      "url": "_framework\/System.Diagnostics.TraceSource.dll"
    },
    {
      "hash": "sha256-QfHNkvP3aPJWHz11m0vtXas7c7z7GSLvXlrkMzwX5+4=",
      "url": "_framework\/System.Diagnostics.Tracing.dll"
    },
    {
      "hash": "sha256-X\/T9qlI1dJvgEaTbCILgXXRkV62K6w4eW2Xt8qjPAeU=",
      "url": "_framework\/System.Drawing.Primitives.dll"
    },
    {
      "hash": "sha256-iF4wiByNSZXZKz5OadiMIrTF8oRT5Xm6F0tH5pJi9+k=",
      "url": "_framework\/System.Drawing.dll"
    },
    {
      "hash": "sha256-vozAxZy4rVudH9vJkYKXeZx4+DPfOhkPYZ6f+4fek8M=",
      "url": "_framework\/System.Dynamic.Runtime.dll"
    },
    {
      "hash": "sha256-25AYkuAqYUcqabWsCqdmYGvZNVY99hZOk6XhHHagyWQ=",
      "url": "_framework\/System.Formats.Asn1.dll"
    },
    {
      "hash": "sha256-ljll0gvYUyBpXdNseAXYiwg1YfjWTonQL+zZSlzhm3k=",
      "url": "_framework\/System.Globalization.Calendars.dll"
    },
    {
      "hash": "sha256-E1Y1qwDlSh\/HBxu62Gm91D6M4wNTpQ2qJGOCGRwTzuA=",
      "url": "_framework\/System.Globalization.Extensions.dll"
    },
    {
      "hash": "sha256-ZBHFkWicw51\/my\/+HFd5YyA39klJlgL9zgaxmnjGnN0=",
      "url": "_framework\/System.Globalization.dll"
    },
    {
      "hash": "sha256-I7H+fbvEt2DdJ+JfChkCIimQon7eK+zqY1SXadcgKx0=",
      "url": "_framework\/System.IO.Compression.Brotli.dll"
    },
    {
      "hash": "sha256-PUjw491x7XXq+IDI0d3RGLPRD+TX49\/nqh77ADm5Lgg=",
      "url": "_framework\/System.IO.Compression.FileSystem.dll"
    },
    {
      "hash": "sha256-rAErCw9QBPoct3o1Re\/fu1xARmeCaaFvE1B8L37zRyQ=",
      "url": "_framework\/System.IO.Compression.ZipFile.dll"
    },
    {
      "hash": "sha256-NGH6dCSFS4Mlb4V0bieRznDv2\/bRHlyKvo0R\/o+1FlQ=",
      "url": "_framework\/System.IO.Compression.dll"
    },
    {
      "hash": "sha256-4Fiu1qh5Qg3J4jr2mzmJOtj3VKTDZ3bmS5bmEywJPUw=",
      "url": "_framework\/System.IO.FileSystem.AccessControl.dll"
    },
    {
      "hash": "sha256-nwBxdLzL2nbhnVotooRSzkxaASVpjHM0JJZLNhCpj+A=",
      "url": "_framework\/System.IO.FileSystem.DriveInfo.dll"
    },
    {
      "hash": "sha256-iEduLhTClh\/6lew\/XZa4rDHvv0UC0rnR7B5ZhO305cY=",
      "url": "_framework\/System.IO.FileSystem.Primitives.dll"
    },
    {
      "hash": "sha256-fVbdXmtCuc9lkccmXl4HvzMTzyQBmH5BnMkXqKYsM20=",
      "url": "_framework\/System.IO.FileSystem.Watcher.dll"
    },
    {
      "hash": "sha256-QVRJ2lL4DjFbrlXTCt2l8bs77ywZl0faiz6TQTMGoCE=",
      "url": "_framework\/System.IO.FileSystem.dll"
    },
    {
      "hash": "sha256-yjvQzggGofdEuliDZDphQk6iXpsuylfGltFS6TUrxOM=",
      "url": "_framework\/System.IO.IsolatedStorage.dll"
    },
    {
      "hash": "sha256-D2JpngRClAW4oJ1NPeP8fKIiHXUKWm93+DjljzT2FLo=",
      "url": "_framework\/System.IO.MemoryMappedFiles.dll"
    },
    {
      "hash": "sha256-qq1smZdRtQydKY4Waey4g+tF4rF1kKJlMhdLmvxW3RA=",
      "url": "_framework\/System.IO.Pipes.AccessControl.dll"
    },
    {
      "hash": "sha256-MRTjIIDCuvj3mif6eEkvJyEghFUGCj\/wyfU3IQYRFcg=",
      "url": "_framework\/System.IO.Pipes.dll"
    },
    {
      "hash": "sha256-P8tMbwhSxkCwn951XM40xCgvzhH6y40zYsxC55G05Mg=",
      "url": "_framework\/System.IO.UnmanagedMemoryStream.dll"
    },
    {
      "hash": "sha256-jUqNUOfso5+v732ZsVH9LNf4\/e0\/iUwewC4GHCfg\/3g=",
      "url": "_framework\/System.IO.dll"
    },
    {
      "hash": "sha256-xvtfMfO9XdbnvIpADBikVQs0JDfOqZYch0igx7rUkbM=",
      "url": "_framework\/System.Linq.Expressions.dll"
    },
    {
      "hash": "sha256-LGWCMp\/DDvYt\/Gw8fKUnuFb4Er5lUgtwO0XijgR+d34=",
      "url": "_framework\/System.Linq.Parallel.dll"
    },
    {
      "hash": "sha256-AHkqDn\/ubqC865Lf19Z3Pa0kUxyqSpx+Coey2KHrgWo=",
      "url": "_framework\/System.Linq.Queryable.dll"
    },
    {
      "hash": "sha256-LVzL8q1AI3pu8LUnsxAGMFNlH4KpL5WQMfsxsEtxljU=",
      "url": "_framework\/System.Linq.dll"
    },
    {
      "hash": "sha256-Hl4e4U4px0ckMlV66v5X5MfXyH5BNEoR5LAjQ47zuUs=",
      "url": "_framework\/System.Memory.dll"
    },
    {
      "hash": "sha256-amCJldi+lVWRc+dLlgWFyWT9UPXDc1clWr4sNB1LY9s=",
      "url": "_framework\/System.Net.Http.Json.dll"
    },
    {
      "hash": "sha256-nBgdAlMEwXcpqusapjOgm\/oK10zW\/AYkEAcWqZp4muk=",
      "url": "_framework\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-luIeJJkTAA9TAJj22US7RK\/\/W5Z9AJpJ8blgzfgdAC0=",
      "url": "_framework\/System.Net.HttpListener.dll"
    },
    {
      "hash": "sha256-5IR+W4AA7TGTA3nI1zR1daNtn7thX\/ObWpnMt3c7vyI=",
      "url": "_framework\/System.Net.Mail.dll"
    },
    {
      "hash": "sha256-W3oqg2+G00FOufNGNl0CB1Vp8lcLq8fks7xKPZVBXMI=",
      "url": "_framework\/System.Net.NameResolution.dll"
    },
    {
      "hash": "sha256-SHmE8mpwpUhWCZM5XteDYArGOozxbxELsA1JUjaXEpY=",
      "url": "_framework\/System.Net.NetworkInformation.dll"
    },
    {
      "hash": "sha256-TPb52IG60vkOMlY+9wz8bpxqX9uCXjPNC9+I4bfFpxY=",
      "url": "_framework\/System.Net.Ping.dll"
    },
    {
      "hash": "sha256-Ka63DDCMSRrvhedEvij60IfnQvic5L0q7SLGDP7VYbU=",
      "url": "_framework\/System.Net.Primitives.dll"
    },
    {
      "hash": "sha256-bDb1q+\/m8QCxT2E9+ybtQEX9vFlsg8p+rqChTQcsrsg=",
      "url": "_framework\/System.Net.Requests.dll"
    },
    {
      "hash": "sha256-pGnva8wx0rhD1euDQAq9JQ7QsBleooc9Tp\/oOVBsfsY=",
      "url": "_framework\/System.Net.Security.dll"
    },
    {
      "hash": "sha256-Fl3f0vvRtgJLUK\/yGwsuaFJ1RFZlznoChyWXr89dvJY=",
      "url": "_framework\/System.Net.ServicePoint.dll"
    },
    {
      "hash": "sha256-+TjSR9hym6N3a6ZthWDwGkD6b7eYzj7+DP\/v46Na7EY=",
      "url": "_framework\/System.Net.Sockets.dll"
    },
    {
      "hash": "sha256-Tb4mpODHsPYbXyOESTH3K0UwuXr\/ddvwy+hmrJMxBOs=",
      "url": "_framework\/System.Net.WebClient.dll"
    },
    {
      "hash": "sha256-KStPhs4bSrpfTcZ1CESUS8PdC1lbsLFfN3TbVOBPMzg=",
      "url": "_framework\/System.Net.WebHeaderCollection.dll"
    },
    {
      "hash": "sha256-X2mudJYO6Rr9Jr4GPoF9JyMvuZ0yUJ9UgowSDGAgiHg=",
      "url": "_framework\/System.Net.WebProxy.dll"
    },
    {
      "hash": "sha256-XVlvfv8VQYYO2fTtuTapZUu2T2lSlkCz1BbgvDMAxl0=",
      "url": "_framework\/System.Net.WebSockets.Client.dll"
    },
    {
      "hash": "sha256-pIVv8Rj\/wGRgLiLKhDG2+B4ulHRxyKEmTHuMZGMzCxk=",
      "url": "_framework\/System.Net.WebSockets.dll"
    },
    {
      "hash": "sha256-mqn3HLs+eIT\/nyzL09A+pVVPENe7VdiYnDdgS4JXpcw=",
      "url": "_framework\/System.Net.dll"
    },
    {
      "hash": "sha256-UjX0bv4\/O0NtwNVlC51lNY14u+XFiz1UGMorr1BlZDs=",
      "url": "_framework\/System.Numerics.Vectors.dll"
    },
    {
      "hash": "sha256-g2bsL7baXXijdWbgcJNYvwUgF1KQJDBlNJoUPur2ka4=",
      "url": "_framework\/System.Numerics.dll"
    },
    {
      "hash": "sha256-nOz6i41YaBGMOWlNNqXTOgBVDARs3VXszd6qHYIhwtI=",
      "url": "_framework\/System.ObjectModel.dll"
    },
    {
      "hash": "sha256-SJ9VeODuF\/HsfhXOINR51Nj8fa4a9nkg1zZoH4I0DBg=",
      "url": "_framework\/System.Private.DataContractSerialization.dll"
    },
    {
      "hash": "sha256-D19hZ9+eHc1BKzSnAFDHoEhxnBeh4PTSInlYs4Brf8o=",
      "url": "_framework\/System.Private.Runtime.InteropServices.JavaScript.dll"
    },
    {
      "hash": "sha256-nYInlidIUA5HuAdlTf5VeEEs01+yb2dYOuDOSHntjyc=",
      "url": "_framework\/System.Private.Uri.dll"
    },
    {
      "hash": "sha256-Cz3vw3k+outESiSj04lK9d+tM8XGB+NFyMtpGxRqwg0=",
      "url": "_framework\/System.Private.Xml.Linq.dll"
    },
    {
      "hash": "sha256-mLMITO8qa0zQ6H9yvqVetw8RGmR9JcW9\/117tapOF+s=",
      "url": "_framework\/System.Private.Xml.dll"
    },
    {
      "hash": "sha256-mTuOlV29DvCS4gP299oliT8ZO6TTEndiUDAj8DN1W7s=",
      "url": "_framework\/System.Reflection.DispatchProxy.dll"
    },
    {
      "hash": "sha256-YGLDtM6HuChK15m35kxBtVUmFJbmo6MetZ+Z7DU43DM=",
      "url": "_framework\/System.Reflection.Emit.ILGeneration.dll"
    },
    {
      "hash": "sha256-dKeVKbw2m+nuaNj+NYIE6D+sNJqEQ0mwr8p8h0sg1IA=",
      "url": "_framework\/System.Reflection.Emit.Lightweight.dll"
    },
    {
      "hash": "sha256-25nimWmODMAlKczI57hkFhBdaxKxMHvMJEGWfHlBjsI=",
      "url": "_framework\/System.Reflection.Emit.dll"
    },
    {
      "hash": "sha256-LMxrpB4Vxy1b5KMQp3mj+y3UWR4EPjORZ0b2UXnEmDk=",
      "url": "_framework\/System.Reflection.Extensions.dll"
    },
    {
      "hash": "sha256-CdkYQWpHHEWBf4H\/0CE7dH6L4Swy8bcXjJtiVzOUuBo=",
      "url": "_framework\/System.Reflection.Metadata.dll"
    },
    {
      "hash": "sha256-RpybWNCtJXaxCcbbXGT2Dc0EhoTGTGGipmb+mnyXvIs=",
      "url": "_framework\/System.Reflection.Primitives.dll"
    },
    {
      "hash": "sha256-UlyO3T9NxAtpCHipIKimfOzI1pGRzxLnzmUX6+ZVVws=",
      "url": "_framework\/System.Reflection.TypeExtensions.dll"
    },
    {
      "hash": "sha256-F6PlwBsHqZs3U1u5EkTovprdmEZNyMJWhrAOUWHxUfg=",
      "url": "_framework\/System.Reflection.dll"
    },
    {
      "hash": "sha256-SNCQsk63iKYgoAY0EBLDfXItQDp3IXDjamC8AwySB3I=",
      "url": "_framework\/System.Resources.Reader.dll"
    },
    {
      "hash": "sha256-uVTmtXNNZKAkk3VmifM+u4lMrnDnDt1XUA483r3IwLo=",
      "url": "_framework\/System.Resources.ResourceManager.dll"
    },
    {
      "hash": "sha256-QF4zTOAxonyn84IGv70PXtweN+kjM32TJa7EeO\/7TFk=",
      "url": "_framework\/System.Resources.Writer.dll"
    },
    {
      "hash": "sha256-7UH3tmCEmVCwgr7\/0eQY0qWb+8j9kDCsTLUEhQYUJs0=",
      "url": "_framework\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-NdB5YzUqKKzS0PiwlOUaNWpKU23w7gwn9RWje+CoCow=",
      "url": "_framework\/System.Runtime.CompilerServices.VisualC.dll"
    },
    {
      "hash": "sha256-rO5KVFes9Xr1LFoZo4\/8qgh0VnHaAQerufM\/ZWEhIPA=",
      "url": "_framework\/System.Runtime.Extensions.dll"
    },
    {
      "hash": "sha256-tYhpDjreCVRCNDX03okDl8A\/Uj\/AdtFlZMMaJmBMmI8=",
      "url": "_framework\/System.Runtime.Handles.dll"
    },
    {
      "hash": "sha256-9Jq6uAx+Dxlh8uWqJPWS+7PCGbNE3sQ\/0LM0a2pQhPI=",
      "url": "_framework\/System.Runtime.InteropServices.RuntimeInformation.dll"
    },
    {
      "hash": "sha256-PZuSUCc0khnJcdwmcxFnPrHbx123xiUg1TlImDEBuA8=",
      "url": "_framework\/System.Runtime.InteropServices.dll"
    },
    {
      "hash": "sha256-vCeF4Hq\/6nBDMf+9PFr68aDTkwR0Bu4iS9KBgph7Dqg=",
      "url": "_framework\/System.Runtime.Intrinsics.dll"
    },
    {
      "hash": "sha256-ouOxupxxWJIn6FKuOrWmZasgt32zSTfwkzZ7qSCmFTI=",
      "url": "_framework\/System.Runtime.Loader.dll"
    },
    {
      "hash": "sha256-xRV\/KJtBLu7mL7aTPQU5WnyQaPukLvqmWI1iK9V0Mu0=",
      "url": "_framework\/System.Runtime.Numerics.dll"
    },
    {
      "hash": "sha256-NqKsp442Q6FhCCVsIHL2GgPAV5jMmfWVbKMYmtbeEEY=",
      "url": "_framework\/System.Runtime.Serialization.Formatters.dll"
    },
    {
      "hash": "sha256-5DZcZIPPDR++dQ\/OWnpcgDb2D7ct68O9+k7\/NVr+7Ug=",
      "url": "_framework\/System.Runtime.Serialization.Json.dll"
    },
    {
      "hash": "sha256-YD3l8NyO0hvIaMlW0DHT8M+LK5PniA5DrznFMUzjQV0=",
      "url": "_framework\/System.Runtime.Serialization.Primitives.dll"
    },
    {
      "hash": "sha256-6YzenhJndjtDhipgvzm4Jpneibcv2TBGFYew2DWdq5A=",
      "url": "_framework\/System.Runtime.Serialization.Xml.dll"
    },
    {
      "hash": "sha256-KwqdnotnJzgXrkK0qAQbNKijsPaWY\/GtGv\/j5R2bbpg=",
      "url": "_framework\/System.Runtime.Serialization.dll"
    },
    {
      "hash": "sha256-6sO4vlBhUIAJag+hWIsjnlHxbbIbj5vKUi4G9dj+2TE=",
      "url": "_framework\/System.Runtime.dll"
    },
    {
      "hash": "sha256-NvkmvGKePQQIBy3EgZK3+Ivy82xjHbJP++9uXTVAnsk=",
      "url": "_framework\/System.Security.AccessControl.dll"
    },
    {
      "hash": "sha256-dQ7XJ3OSIgKjQTHRLKjRzGlSn3DyAXsX7bZPXfW03CU=",
      "url": "_framework\/System.Security.Claims.dll"
    },
    {
      "hash": "sha256-b7bu6Eq8G55ftD63fn6yce\/Bd3zmb+IRpnRGxxHoFGo=",
      "url": "_framework\/System.Security.Cryptography.Algorithms.dll"
    },
    {
      "hash": "sha256-buJfM0cXGNhWLXgLAo1HaFfZgrOIf\/u1OKlzLis6AhE=",
      "url": "_framework\/System.Security.Cryptography.Cng.dll"
    },
    {
      "hash": "sha256-8TesCDE+B+Gq3IsLi1GPxol4IDMtuhNxHZ1KQRY0e7I=",
      "url": "_framework\/System.Security.Cryptography.Csp.dll"
    },
    {
      "hash": "sha256-ZTH5U5R+eg4fY7kjWgxB5BKZb6S7ywePuCN1JtJEWFc=",
      "url": "_framework\/System.Security.Cryptography.Encoding.dll"
    },
    {
      "hash": "sha256-dr7PtVvcF7UWKpxxN\/8T19PQWwtrkCeWxSyHuznGxuE=",
      "url": "_framework\/System.Security.Cryptography.OpenSsl.dll"
    },
    {
      "hash": "sha256-Se5e4uwQOHMT90rEjVIhpRz7iqqD7Z1BVbnM6ypwsnI=",
      "url": "_framework\/System.Security.Cryptography.Primitives.dll"
    },
    {
      "hash": "sha256-AFbPGIny3XmhqdHBf8BLJjuJNNsmZ5dI3WaXIakacsY=",
      "url": "_framework\/System.Security.Cryptography.X509Certificates.dll"
    },
    {
      "hash": "sha256-DDzIBEl\/5dfmjmiM6N4yIZFiBioiN67lI8rDXs9E2Uw=",
      "url": "_framework\/System.Security.Principal.Windows.dll"
    },
    {
      "hash": "sha256-XZ\/7EGuz3McTY4yaH4b0dIEJH4QrWy45GmrgVC\/awKs=",
      "url": "_framework\/System.Security.Principal.dll"
    },
    {
      "hash": "sha256-mGZaM0lCjpZ5YUtDfikjKEkiB7JA5nzn6RLYeuuqPsE=",
      "url": "_framework\/System.Security.SecureString.dll"
    },
    {
      "hash": "sha256-KfNa\/kBDygZTusiFdZgx7BE9POqBRVi1gGZLV41BHl4=",
      "url": "_framework\/System.Security.dll"
    },
    {
      "hash": "sha256-ZADOKVD4gvlwrY1QyluLQDFi4JiUx3TDceRLS1BkVH0=",
      "url": "_framework\/System.ServiceModel.Web.dll"
    },
    {
      "hash": "sha256-mbspMF3K1zEyLVSkRSOMOThsQoKZ\/P7wZwWtqqt+J+U=",
      "url": "_framework\/System.ServiceProcess.dll"
    },
    {
      "hash": "sha256-fsJMzdjSldbdaXQ4hdkCfxMF+SgdzT\/tgfmjtpDOHW8=",
      "url": "_framework\/System.Text.Encoding.CodePages.dll"
    },
    {
      "hash": "sha256-yZDcYfLCGJHD\/wVq7hedXRfpqiE1vvngbkECERLfMo4=",
      "url": "_framework\/System.Text.Encoding.Extensions.dll"
    },
    {
      "hash": "sha256-hwA9E3wv7sr0V6TcCRCNCF2VuHyqvEPKjC5Lxft11Uk=",
      "url": "_framework\/System.Text.Encoding.dll"
    },
    {
      "hash": "sha256-b3RadEAfg8L4drVrEgJp2HSZCwnEMZiPAfW50SwC4e4=",
      "url": "_framework\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-xeiyqb+S+fIB4IXtEEcJFrsep2F3u3rZQn4sIbXQF+M=",
      "url": "_framework\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-taMNZa\/iWv71Xs1LH42Y40hvBOX41twP8ZUIYM9sTow=",
      "url": "_framework\/System.Text.RegularExpressions.dll"
    },
    {
      "hash": "sha256-Rwt45zvmuTcXNe32o24qaTXDeW8s1Qvh8Cfx0WHs0GA=",
      "url": "_framework\/System.Threading.Channels.dll"
    },
    {
      "hash": "sha256-aHj+rCcmFz4d7rr5af\/DgrYE+xLsQ7wv267QICANxrA=",
      "url": "_framework\/System.Threading.Overlapped.dll"
    },
    {
      "hash": "sha256-NCM8u3xumosZ+i+8y0NE3FGdu6Jjr34R0eiUK7EdahQ=",
      "url": "_framework\/System.Threading.Tasks.Dataflow.dll"
    },
    {
      "hash": "sha256-E88HYEzfhhfmDyRE+QvWXr2Phk6dERvo5Y5qqIo12uU=",
      "url": "_framework\/System.Threading.Tasks.Extensions.dll"
    },
    {
      "hash": "sha256-0SkbS4TqQevsB3XYV7scYmp+SP+grdHnUMytl2swGAo=",
      "url": "_framework\/System.Threading.Tasks.Parallel.dll"
    },
    {
      "hash": "sha256-SxhYLvoyXmzTnEAJhKg4GA0tUmAMRS8607bAppEmVqo=",
      "url": "_framework\/System.Threading.Tasks.dll"
    },
    {
      "hash": "sha256-33c3yt1RV0SWSoQDIKehsWi91dXcBYIZmZ\/sW0x+N+E=",
      "url": "_framework\/System.Threading.Thread.dll"
    },
    {
      "hash": "sha256-NrqpDEIOG1YfLmcby9iSRzfihPUeTJlRM0ldkrko\/D4=",
      "url": "_framework\/System.Threading.ThreadPool.dll"
    },
    {
      "hash": "sha256-4OI2qSTEhLQ0nZ+boXBkIMAFya5ThCowoR8rx8hxZQo=",
      "url": "_framework\/System.Threading.Timer.dll"
    },
    {
      "hash": "sha256-ri9RqLQnWBeIVG4fXw0lR4elbXg8v1VdZ3yG4PmKFEo=",
      "url": "_framework\/System.Threading.dll"
    },
    {
      "hash": "sha256-dQiM+wM0uZgyDe0BhyTisnFrhdUEwRlqhBttw\/IURpU=",
      "url": "_framework\/System.Transactions.Local.dll"
    },
    {
      "hash": "sha256-20G3ZAEP8pA65HAxnCQOT83sFXOT4wJwAhztolp\/ncA=",
      "url": "_framework\/System.Transactions.dll"
    },
    {
      "hash": "sha256-8jJBKbLNmchaibi3jFatrV3W8FH4yMgUUUATgYBxIrU=",
      "url": "_framework\/System.ValueTuple.dll"
    },
    {
      "hash": "sha256-lIL6yGdx3u89owgrE6hwurDxB+F0eKD744RbmpZwask=",
      "url": "_framework\/System.Web.HttpUtility.dll"
    },
    {
      "hash": "sha256-VUQg8AbhQxTrgOr\/qVvKzTajgo9PP0twxHFyxwRIy+g=",
      "url": "_framework\/System.Web.dll"
    },
    {
      "hash": "sha256-zbHdSTGUJv2iclv2nVFRcXneprGanS2bsrucFunZ\/0I=",
      "url": "_framework\/System.Windows.dll"
    },
    {
      "hash": "sha256-X+n0c4U\/ovw8P3xIMUKedtlICcsHuWTUmTfcARSlnis=",
      "url": "_framework\/System.Xml.Linq.dll"
    },
    {
      "hash": "sha256-RAb3ZdRbdrPoovHHEviwJ03CLTHEu+kAiTdcvnCx9dA=",
      "url": "_framework\/System.Xml.ReaderWriter.dll"
    },
    {
      "hash": "sha256-Z2ietSKGVpPTFVvwQRER8Goyw+xlFjRtJjf7paKjvmo=",
      "url": "_framework\/System.Xml.Serialization.dll"
    },
    {
      "hash": "sha256-7jm0ivvQwJpKEZySZhXjIn6x8a\/5L1kVA56rGNRBgU0=",
      "url": "_framework\/System.Xml.XDocument.dll"
    },
    {
      "hash": "sha256-MpyIRQYmFQqp9R9HmZEJv7P2+vPzKufoHa+O79jj5xs=",
      "url": "_framework\/System.Xml.XPath.XDocument.dll"
    },
    {
      "hash": "sha256-lR90JPdItN3LUnmbH\/QecAPeJ3KTLu9c9cOPEBKbK\/o=",
      "url": "_framework\/System.Xml.XPath.dll"
    },
    {
      "hash": "sha256-Ek1ecNfvIV9dMTp+ysG7wxvvigzF6NGkco3Eo+4J8og=",
      "url": "_framework\/System.Xml.XmlDocument.dll"
    },
    {
      "hash": "sha256-x5bgttc3rthehmRu\/a7UF25Q9efdSKxaxPl6rm60Dkw=",
      "url": "_framework\/System.Xml.XmlSerializer.dll"
    },
    {
      "hash": "sha256-xPFlM0IO6Db2eIx0k6W3Gs7fTNVnCY4T8nDaeQc66xI=",
      "url": "_framework\/System.Xml.dll"
    },
    {
      "hash": "sha256-JnagunPdmbLzdqRvEXqGdBw9zYcRGp5XCSYQmpQV8fs=",
      "url": "_framework\/System.dll"
    },
    {
      "hash": "sha256-cN9PUik1\/7SqVLkfg2mEKKDY\/Ij4zufsSmwcojDuWDk=",
      "url": "_framework\/WindowsBase.dll"
    },
    {
      "hash": "sha256-i0zXLOX1XZekwNvRdQK9WDvRWKFggLp7KDCnvMrn+HQ=",
      "url": "_framework\/mscorlib.dll"
    },
    {
      "hash": "sha256-4QNBIB4DMwj82CYd96oFrTh3fcrmyaDjtQ2dBTyWz7Q=",
      "url": "_framework\/netstandard.dll"
    },
    {
      "hash": "sha256-5Zk+rN+j5FbFEQJdT8YR2O0i6KWpvrERsaPZCv69DmI=",
      "url": "_framework\/System.Private.CoreLib.dll"
    },
    {
      "hash": "sha256-2ldEe2K8ARFKSIBsv+Hr3iNQzq9qh1H\/dwdu2r+AIyY=",
      "url": "_framework\/dotnet.timezones.blat"
    },
    {
      "hash": "sha256-XmG1o3XoL4Dv4DjPhf+gJzrOdCMk+8d4f30sHkRIlzA=",
      "url": "_framework\/dotnet.wasm"
    },
    {
      "hash": "sha256-m7NyeXyxM+CL04jr9ui1Z6pVfMWwhHusuz5qNZWpAwA=",
      "url": "_framework\/icudt.dat"
    },
    {
      "hash": "sha256-91bygK5voY9lG5wxP0\/uj7uH5xljF9u7iWnSldT1Z\/g=",
      "url": "_framework\/icudt_CJK.dat"
    },
    {
      "hash": "sha256-DPfeOLph83b2rdx40cKxIBcfVZ8abTWAFq+RBQMxGw0=",
      "url": "_framework\/icudt_EFIGS.dat"
    },
    {
      "hash": "sha256-oM7Z6aN9jHmCYqDMCBwFgFAYAGgsH1jLC\/Z6DYeVmmk=",
      "url": "_framework\/icudt_no_CJK.dat"
    },
    {
      "hash": "sha256-rip887O\/MzF0Xf3GXtIvfySYu+t66+HDS8TyLMVM1Ss=",
      "url": "_framework\/dotnet.5.0.0.js"
    },
    {
      "hash": "sha256-bAT5D87EkSa8pczQ2S5KnffFquSfHvPLkg7NNBEiCqQ=",
      "url": "BlazorPublishFolder.styles.css"
    },
    {
      "hash": "sha256-GHsyG\/GZLz4v1DjyO7zklflkgMDQ78UD5qfS3OsuThA=",
      "url": "_framework\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-j4IzG2+94lnbTZaGoarDQNbAjJfk5+6e9LCARAEo82g=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-I2vZy3fijpIHqo9HBq9dTyHxiuSUHpB+ZvXP03HXqD0=",
      "url": "_framework\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-R6lgTmWZQPc8zEQZSIkTb6Cw6TRDR9DlssL\/q1fTG4g=",
      "url": "_framework\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-F9I+0e7EyaafnAUWdWoVvklWg1Fj5AQpEpDvLA9WQ7U=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-DcTOo9gXOu6Rpr8D85aQmt5KRX\/v1xwAZLlldyUHK3E=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-7ISrD6YrF1C3AuZBaIgaJhPcvD8xwXmKCXgDOaNMqRE=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-nFOzP2WKCWLDJkaeR8scIWbsDRPdHVZc6uCoIgYwLgY=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-IUhu1giGYMNMj9YZivDxUGbU9UPFMq1UoheVQDZXIE8=",
      "url": "_framework\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-1qMpq0WGanfSymZ7G9G2miVo\/3nU28VSxiJkuAkU6m4=",
      "url": "_framework\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-G+pRSzA7e8kfyDv69bfOqUSGBuMfM+PsRIetL71fwd4=",
      "url": "_framework\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-vpj6p5lL2M+GsRVAI+VVi3I\/dpflkVJLcloOS52D\/\/8=",
      "url": "_framework\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-0o\/vt4NH\/VfmWZxWcdLsy7WlafnyiNlCMmFoL1QmfMg=",
      "url": "_framework\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-5AkXTXHIeXryrSr97JWjBrndsRjoslMVJ8e7FqupHUw=",
      "url": "_framework\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-qj+ITVhmJUAkSBctDayU4uUjNTKdXqAbF2zAxo7\/mkM=",
      "url": "_framework\/System.IO.Pipelines.dll"
    },
    {
      "hash": "sha256-96ILUdDoi7RbkVlc7nIdFo9Su8HHYYb63bZKQzoQH9g=",
      "url": "_framework\/BlazorPublishFolder.dll"
    },
    {
      "hash": "sha256-sFuryTSkvLhG6KkfGH6PPaK9LKwqi1VvX0j\/lpquNCE=",
      "url": "_framework\/blazor.boot.json"
    },
    {
      "hash": "sha256-aUUhSORllrlw6mUXuKFR72wUPfryKu60ogDqZUdBukM=",
      "url": "_framework\/blazor.webassembly.js"
    }
  ],
  "version": "t5fusVxh"
};
